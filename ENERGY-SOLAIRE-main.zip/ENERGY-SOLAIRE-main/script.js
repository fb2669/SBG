function ouvrirFormulaire() {
    const formulaire = document.getElementById("formulaire");
    formulaire.classList.toggle("hidden");
}
